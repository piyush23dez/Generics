//: Playground - Type Constraints


protocol MyProtocol {}

extension Int: MyProtocol {}
extension String: MyProtocol {}

struct LifoQueue<T: MyProtocol> {
    var items = [T]()
    
    mutating func append(item: T) {
        items.append(item)
    }
    
    mutating func remove() {
        items.remove(at : 0)
    }
}

var stringQueue = LifoQueue<String>()
stringQueue.append(item: "piyush")
stringQueue.append(item: "Abhas")
print(stringQueue.items)

//Error
//let queue = LifoQueue<Double>()



//Example 1

class Phone {}
class Mac {}
class TV {}

class Gift<T> {
    
    var items = [T]()
    
    func add(item: T) {
        items.append(item)
    }
    
    func size() -> Int {
        return items.count
    }
}

var gift1 = Gift<Phone>()
gift1.add(item: Phone())

var gift2 = Gift<TV>()
gift2.add(item: TV())

var gift3 = Gift<Mac>()
gift3.add(item: Mac())


//Example 2
class Photo { }

class Album<T: Photo> {
    var items = [T]()
}

let album = Album<Photo>()
//let album = Album<Phone>() //error




//Example 3

struct Stack<T, E: Hashable> {
    
    var items: Array<T> = Array<T>()
    var dict = [E: T]()
    
    mutating func push(item: T) {
        items.append(item)
    }
    
    mutating func pop() -> T?  {
        guard let lastItem = items.popLast() else {
            return nil
        }
        return lastItem
    }
}

var myStack = Stack<String, Int>()
myStack.push(item: "Piyush")
myStack.push(item: "Abhas")
myStack.push(item: "Mohit")
myStack.items


